<?php
//include('inc/connection.php');
session_start();
 // check if user login or not 
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php#log'); 
    exit();
}
  // tols part 
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $url = $_POST["Url"];
    $url = stripcslashes($_POST['Url']);
    //$url = htmlentities(mysqli_real_escape_string($con,$_POST['Url']));

    // Execute Bash script with URL as argument
  //$output1 = shell_exec("bash ffuf.sh " . escapeshellarg($url));

    // Display output in HTML format
   // echo "<pre>$output</pre>";
    
    //$output2 = shell_exec("bash Nuclei.sh " . escapeshellarg($url));
    $output1 = shell_exec("bash nmap.sh " . escapeshellarg($url));
    $output2 = shell_exec("bash extract_cve.sh ");
    $output3 = shell_exec("bash ai.sh ");
   }
function extractCvesAndLinks($output) {
    $lines = explode("\n", $output);
    $cves = [];

    foreach ($lines as $line) {
        if (preg_match('/\b(CVE-\d{4}-\d{4,})\b/i', $line, $matches)) {
            $cves[] = [
                'cve' => $matches[1],
                'link' => "https://cve.mitre.org/cgi-bin/cvename.cgi?name=" . $matches[1]
            ];
        }
    }

    return $cves;
}

$cves = extractCvesAndLinks($output3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Script Output</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        a {
            color: #3498db;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Script Output</h1>
        <!-- Display the output in a table -->
        <?php if (!empty($cves)): ?>
            <table>
                <thead>
                    <tr>
                        <th>CVE</th>
                        <th>Patch Link</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cves as $cve): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($cve['cve']); ?></td>
                            <td><a href="<?php echo htmlspecialchars($cve['link']); ?>" target="_blank">Patch Link</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>This report does not exist CVEs.</p>
        <?php endif; ?>
    </div>
</body>
</html>
