#!/bin/bash

cd simple_chat_ai
php response2.php


